package com.example.georg.ictprojectantwoordnakijken;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Object vragen en antwoorden
 *
 * Created by georg on 12/10/2017.
 */

public class VraagEnAntwoord {
    private String vraag;
    private ArrayList<String> fouteAntwoorden;
    private String juisteAntwoord;
    private ArrayList<String> totaalAntwoorden;

    public VraagEnAntwoord(String iniVraag, ArrayList<String> iniFouteAntwoorden, String iniJuisteAntwoord){

        this.vraag = iniVraag;
        this.fouteAntwoorden = iniFouteAntwoorden;
        this.juisteAntwoord = iniJuisteAntwoord;

        totaalAntwoorden= fouteAntwoorden;
        totaalAntwoorden.add(juisteAntwoord);
    }


    public String getVraag() {
        return vraag;
    }

    public List<String> getFouteAntwoorden() {
        return fouteAntwoorden;
    }

    public String getJuisteAntwoord() {
        return juisteAntwoord;
    }

    public Integer getAantalAntwoorden(){
        return fouteAntwoorden.size() + 1;
    }

    public List<String> getTotaalAntwoorden(){
        Collections.shuffle(totaalAntwoorden);
        return  totaalAntwoorden;
    }

    public String getAntwoord(int index){
        return  totaalAntwoorden.get(index);
    }
}
