package com.example.georg.ictprojectantwoordnakijken;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

public class MainActivity extends Activity implements View.OnClickListener {


    private Db_handler db_handler;

    private List<Button> buttons;

    private TextView vraag;
    private Integer aantalVragen;
    private Integer count;
    private VraagEnAntwoord vraagEnAntwoord;
    private Boolean answeredCorrect;

    //layout settings
    LinearLayout linearLayout;
    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);



    public void setup(){
        //locale waarde
        db_handler = new Db_handler();
        count = 0;
        buttons = new ArrayList<>();
        aantalVragen = 3;
        linearLayout =  (LinearLayout) findViewById(R.id.buttonsLayout);;

        vraag = (TextView) findViewById(R.id.vraagTextView);
        //Eerste vraag afhalen
        vraagEnAntwoord = db_handler.getVraagEnAntwoord(count);
        //buttons toevoegen aan layout
        createButtons();
    }

    //buttons dynamish aanmaken aan de hand van aantal antwoorden
    private void createButtons(){
         vraag.setText(vraagEnAntwoord.getVraag());
         linearLayout.removeAllViews();

         for(int i = 0; i<vraagEnAntwoord.getAantalAntwoorden()-1;i++ ){
             Button button = new Button(this);
             button.setText(vraagEnAntwoord.getAntwoord(i));
             button.setTextSize(14);
             button.setGravity(Gravity.CENTER);
             button.setId(i);
             button.setLayoutParams(params);
             //button.setSingleLine(true);
             //button.setHeight((int    )"wrap_content");
             button.setOnClickListener(this);

             buttons.add(button);
             linearLayout.addView(button);
         }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setup();
    }

    @Override
    public void onClick(View view) {

         answeredCorrect = checkAnswerQuestion( (Button)view);

    }

    boolean checkAnswerQuestion(Button button){

       if(button.getText()== vraagEnAntwoord.getJuisteAntwoord()){
           count++;
           if (aantalVragen-1 >= count){
               vraagEnAntwoord = db_handler.getVraagEnAntwoord(count);

               createButtons();
           }
           else{
               //Quiz capture and cooldown
               overnemenSucces();
           }

        }else{
           eindeQuiz();

           return false;
        }
        return true;
    }

    public  void eindeQuiz(){
        count = 0;
        Toast.makeText(getApplicationContext(), "Fout antwoord, Quiz is gedaan en vlag gaat op cooldown.", Toast.LENGTH_SHORT).show();
        vraagEnAntwoord = db_handler.getVraagEnAntwoord(count);
        createButtons();
    }

    public void overnemenSucces(){
        Toast.makeText(getApplicationContext(),"U heeft de vlag succesvol overgenomen!", Toast.LENGTH_SHORT).show();
        count=0;
        createButtons();
    }
}
