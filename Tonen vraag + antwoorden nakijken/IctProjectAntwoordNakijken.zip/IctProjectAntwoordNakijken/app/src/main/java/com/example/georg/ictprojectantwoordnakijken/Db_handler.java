package com.example.georg.ictprojectantwoordnakijken;

import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by georg on 12/10/2017.
 */


public class Db_handler {

    //Array van Vraag en Antwoorden
    private Vector<VraagEnAntwoord> vraagEnAntwoorden = new Vector<VraagEnAntwoord>();

    public Db_handler(){

        //toevoegen vragen en antwoorden van de vraag
        String vraagString = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce sem ligula, mattis eget elit a, cursus venenatis neque. Mauris luctus viverra nisl nec gravida. Ut aliquet nec velit eu tempus. Mauris sodales, velit vel imperdiet varius, nunc lacus aliquam massa, bibendum pharetra libero dolor et massa. Nam viverra ante sed magna bibendum rhoncus. Etiam facilisis, lacus quis fermentum posuere, est est tristique enim, at iaculis sem elit quis metus. Curabitur at pretium diam.";

        VraagEnAntwoord vraag = new VraagEnAntwoord(vraagString,new ArrayList<String>(){{
            add("fout1");
            add("fout2");
            add("fout3");
        }},"juist");
        vraagEnAntwoorden.add(vraag);

        vraag = new VraagEnAntwoord(vraagString,new ArrayList<String>(){{
            add("fout4");
            add("fout5");
            add("fout6");
            add("fout8");
            add("fout7");
        }},"juist");
        vraagEnAntwoorden.add(vraag);

        vraag = new VraagEnAntwoord("Van welk land komt Hakan?",new ArrayList<String>(){{
            add("Kazachstan");
            add("Rusland");
        }},"Turkije");
        vraagEnAntwoorden.add(vraag);

        vraag = new VraagEnAntwoord("Waarom is michiel ros?",new ArrayList<String>(){{
            add("Van papa gekregen");
        }},"Van mama gekregen");
        vraagEnAntwoorden.add(vraag);
        vraag = new VraagEnAntwoord(vraagString,new ArrayList<String>(){{
            add("fout4");
            add("fout5");
            add("fout6");
            add("fout8");
            add("fout7");
        }},"juist");
        vraagEnAntwoorden.add(vraag);
    }

    //geef de vraag en antwoorden terug op een bepaalde plaats
    public VraagEnAntwoord getVraagEnAntwoord(Integer index) {
        return vraagEnAntwoorden.get(index);
    }
}
